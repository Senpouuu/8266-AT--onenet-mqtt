var searchData=
[
  ['hardware_20timer_20apis',['Hardware timer APIs',['../group__HW__Timer__APIs.html',1,'']]],
  ['hw_5ftimer_5farm',['hw_timer_arm',['../group__HW__Timer__APIs.html#gace64c59d338a9d785bd5730029086553',1,'hw_timer.h']]],
  ['hw_5ftimer_5finit',['hw_timer_init',['../group__HW__Timer__APIs.html#ga09f8d1ed286cb02bfe47bc5f6c67b570',1,'hw_timer.h']]],
  ['hw_5ftimer_5fset_5ffunc',['hw_timer_set_func',['../group__HW__Timer__APIs.html#ga78c91a9ec46aa9fb5b9fae9d357e9957',1,'hw_timer.h']]]
];
